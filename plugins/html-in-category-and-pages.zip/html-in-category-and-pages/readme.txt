=== .html in category and page url ===
Contributors: dnesscarkey
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=TYPYWFP6P2KQJ
Tags: category, page, url
Requires at least: 3.0.
Tested up to: 3.4.1
Stable tag: 1.0

This plugin add .html in category and page url

== Description ==

This Plugin adds .html (or any extension) in category and page url.

You can change the extension from Plugin Setting page. Don't forget to update the permalink after you change the extension.

Please report any bugs @ http://dineshkarki.com.np/html-in-category-and-page-url/report-bugs.


== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Change the extension from the setting page of the plugin.

== Frequently Asked Questions ==

= Can i change the extension ? =

Yes, you can.

== Changelog ==

= 0.1 =
* First Release